export interface UserType {
  userId: string;
  username: string;
}
