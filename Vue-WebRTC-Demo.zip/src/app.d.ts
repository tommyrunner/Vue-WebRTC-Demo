export interface StateDataType {
  username: string;
  toUserName: string;
  room: string;
}
