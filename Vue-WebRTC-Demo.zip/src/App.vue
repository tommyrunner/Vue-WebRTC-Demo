<template>
  账号
  <input type="text" v-model="stateData.username" />
  <br />
  密码
  <input type="text" v-model="stateData.room" />
  <br />
  拨打用户
  <input type="text" v-model="stateData.toUserName" />
  <video autoplay playsinline controls ref="localVideoRef" style="width: 100px; height: 100px"></video>
  <video autoplay playsinline controls ref="remoteVideoRef" style="width: 200px; height: 200px"></video>
  <button @click="sendOffer">发送</button>
  <button @click="login">进入房间</button>
</template>
<script setup lang="ts">
/**
 * TODO: 必须是域名
 */
import type { StateDataType } from "./app";
import { io, Socket } from "socket.io-client";
import { ref, reactive } from "vue";
const localVideoRef = ref();
const remoteVideoRef = ref();
let stateData = reactive<StateDataType>({
  username: "user01",
  toUserName: "user02",
  room: "001",
});
let socket: Socket;

const userMediaConfig = {
  // 音频
  // audio: true,
  // 视频
  video: true,
};
const rtcConfig: RTCConfiguration = {
  iceServers: [
    {
      urls: ["stun:stun.l.google.com:19302"],
    },
    {
      urls: ["turn:120.77.253.101:3478"],
      username: "inter_user",
      credential: "power_turn",
    },
  ],
};
let localStream: MediaStream;
let localPc: RTCPeerConnection;
let remotePc = new RTCPeerConnection(rtcConfig);
function login() {
  start();
}
function start() {
  socket = io("ws://192.168.0.23:3003/", {
    path: "/rtc",
    query: { username: stateData.username, room: stateData.room },
  });
  socket.on("connect", () => {
    console.log("连接成功");
    initVideo(localVideoRef.value);
  });
  socket.on("pc offer", async (res: { data: RTCSessionDescriptionInit }) => {
    // 接收倒offer
    console.log("接收倒offer", res);
    let remoteDesc = res.data;
    // 创建 answer
    await remotePc.setRemoteDescription(remoteDesc);
    let remoteAnswer = await remotePc.createAnswer();
    await remotePc.setLocalDescription(remoteAnswer);
    socket.emit("pc answer", { data: remoteAnswer, username: stateData.toUserName });
  });
  socket.on("pc answer", async (res: { data: RTCSessionDescription }) => {
    console.log("local接收到 answer", res);
    let remoteAnswer = res.data;
    await localPc.setRemoteDescription(remoteAnswer);
  });
  socket.on("pc candidate", async (res: { data: RTCIceCandidateInit }) => {
    let candidate = res.data;
    console.log("local接收到 candidate：", candidate);
    // 注意需要先注册监听事件，再添加ice
    remotePc.ontrack = (e) => {
      remoteVideoRef.value.srcObject = e.streams[0];
      remoteVideoRef.value.addEventListener("loadedmetadata", () => {
        remoteVideoRef.value.play();
        // 同意的同时向对面发送
        // sendOffer();
      });
    };
    await remotePc.addIceCandidate(candidate);
  });
}
async function initVideo(video: HTMLVideoElement) {
  try {
    // userMediaConfig
    let stream = await navigator.mediaDevices.getDisplayMedia();
    video.srcObject = stream;
    localStream = stream;
  } catch (e) {
    console.log("getDisplayMedia() error: ", e);
  }
}
async function sendOffer() {
  // 初始化当前视频
  localPc = new RTCPeerConnection(rtcConfig);
  // 添加RTC流
  localStream.getTracks().forEach((track) => {
    localPc.addTrack(track, localStream);
  });
  // 给当前RTC流设置监听事件(协议完成回调)
  localPc.onicecandidate = function (event) {
    console.log("localPc：", event.candidate, event);
    // 回调时，将自己candidate发给对方，对方可以直接addIceCandidate(candidate)添加可以获取流
    if (event.candidate) socket.emit("pc candidate", { data: event.candidate, username: stateData.toUserName });
  };
  // 发起方：创建offer(成功将offer的设置当前流，并发送给接收方)
  let offer = await localPc.createOffer();
  // 建立连接，此时就会触发onicecandidate，然后注册ontrack
  await localPc.setLocalDescription(offer);
  socket.emit("pc offer", { data: offer, username: stateData.toUserName });
}
</script>
<style scoped></style>
